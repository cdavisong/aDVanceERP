﻿using aDVanceERP.Core.Infraestructura.Globales;
using aDVanceERP.Modulos.Venta.Interfaces;
using aDVanceERP.Core.Infraestructura.Extensiones.Comun;

using System.Globalization;
using aDVanceERP.Core.Modelos.Modulos.Venta;

namespace aDVanceERP.Modulos.Venta.Vistas {
    public partial class VistaTuplaPedido : Form, IVistaTuplaPedido {
        private EstadoPedidoEnum _estadoPedido;
        private bool _activo;

        public VistaTuplaPedido() {
            InitializeComponent();

            NombreVista = nameof(VistaTuplaPedido);

            Inicializar();
        }

        public string NombreVista {
            get => $"{Name}{Id}";
            private set => Name = value;
        }

        public bool Habilitada {
            get => Enabled;
            set => Enabled = value;
        }

        public Point Coordenadas {
            get => Location;
            set => Location = value;
        }

        public Size Dimensiones {
            get => Size;
            set => Size = value;
        }

        public Color ColorFondoTupla {
            get => layoutVista.BackColor;
            set => layoutVista.BackColor = layoutVista.BackColor = value == Color.Gainsboro
                ? value
                : ObtenerColorFondoTupla(EstadoPedido);
        }

        public bool EstadoSeleccion { get; set; }

        public long Id { get; set; }

        public string Codigo {
            get => fieldCodigo.Text;
            set => fieldCodigo.Text = value;
        }

        public DateTime FechaPedido {
            get => fieldFechaPedido.Text.Equals("-")
                    ? DateTime.MinValue
                    : DateTime.ParseExact(fieldFechaPedido.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            set => fieldFechaPedido.Text = value.Equals(DateTime.MinValue)
                ? "-"
                : value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        public string NombreCliente {
            get => fieldNombreCliente.Text;
            set {
                fieldNombreCliente.Text = value;
                fieldNombreCliente.Margin = fieldNombreCliente.AjusteAutomaticoMargenTexto();
            }
        }

        public DateTime FechaEntrega {
            get => fieldFechaEntrega.Text.Equals("-")
                        ? DateTime.MinValue
                        : DateTime.ParseExact(fieldFechaEntrega.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            set => fieldFechaEntrega.Text = value.Equals(DateTime.MinValue)
                ? "-"
                : value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        public string DireccionEntrega {
            get => fieldDireccionaEntrega.Text;
            set {
                fieldDireccionaEntrega.Text = value;
                fieldDireccionaEntrega.Margin = fieldDireccionaEntrega.AjusteAutomaticoMargenTexto();
            }
        }

        public decimal ImporteTotal {
            get => decimal.TryParse(fieldImporteTotal.Text, NumberStyles.Any, CultureInfo.InvariantCulture,
                                    out var value)
                                    ? value
                                    : 0m;
            set => fieldImporteTotal.Text = value > 0
                    ? value.ToString("N2", CultureInfo.InvariantCulture)
                    : "-";
        }

        public EstadoPedidoEnum EstadoPedido {
            get => _estadoPedido;
            set {
                _estadoPedido = value;
                fieldEstado.Text = value.ObtenerNombreDescripcion();
                fieldEstado.Font = value == EstadoPedidoEnum.Retirado || value == EstadoPedidoEnum.Cancelado ? new Font(new FontFamily("Segoe UI"), 11.25f, FontStyle.Regular) : new Font(new FontFamily("Segoe UI"), 11.25f, FontStyle.Underline);
                fieldEstado.ForeColor = value == EstadoPedidoEnum.Retirado || value == EstadoPedidoEnum.Cancelado ? Color.DimGray : Color.DodgerBlue;
                fieldEstado.Cursor = value == EstadoPedidoEnum.Retirado || value == EstadoPedidoEnum.Cancelado ? Cursors.Default : Cursors.Hand;
                btnEditar.Enabled = value == EstadoPedidoEnum.Pendiente;
                btnCancelar.Enabled = value != EstadoPedidoEnum.Retirado;
                layoutVista.BackColor = ObtenerColorFondoTupla(value);
            }
        }

        public bool Activo {
            get => _activo;
            set {
                _activo = value;
                btnEditar.Enabled = value;
                btnCancelar.Enabled = value;
            }
        }

        public event EventHandler? EditarDatosTupla;
        public event EventHandler? EliminarDatosTupla;
        public event EventHandler<(long idPedido, EstadoPedidoEnum estado)> CambioEstadoPedido;

        public void Inicializar() {
            // Eventos
            fieldEstado.Click += delegate {
                if (EstadoPedido == EstadoPedidoEnum.Retirado || EstadoPedido == EstadoPedidoEnum.Cancelado)
                    return;

                btnEstadoConfirmado.Visible = EstadoPedido == EstadoPedidoEnum.Pendiente;
                btnEstadoPreparando.Visible = EstadoPedido == EstadoPedidoEnum.Confirmado;
                btnEstadoListoParaRetirar.Visible = EstadoPedido == EstadoPedidoEnum.Preparando;
                fieldEstado.ContextMenuStrip?.Show(fieldEstado, new Point(0, 40));
            };
            btnEstadoConfirmado.Click += delegate (object? sender, EventArgs e) { 
                EstadoPedido = EstadoPedidoEnum.Confirmado;
                CambioEstadoPedido?.Invoke(this, (Id, EstadoPedido));
            };
            btnEstadoPreparando.Click += delegate (object? sender, EventArgs e) {
                EstadoPedido = EstadoPedidoEnum.Preparando;
                CambioEstadoPedido?.Invoke(this, (Id, EstadoPedido));
            };
            btnEstadoListoParaRetirar.Click += delegate (object? sender, EventArgs e) {
                EstadoPedido = EstadoPedidoEnum.ListoParaRetirar;
                CambioEstadoPedido?.Invoke(this, (Id, EstadoPedido));
            };
            btnEditar.Click += delegate (object? sender, EventArgs e) { EditarDatosTupla?.Invoke(this, e); };
            btnCancelar.Click += delegate (object? sender, EventArgs e) { 
                EstadoPedido = EstadoPedidoEnum.Cancelado;
                CambioEstadoPedido?.Invoke(this, (Id, EstadoPedido));
            };
        }

        public void Mostrar() {
            BringToFront();
            Show();
        }

        public void Restaurar() {
            ColorFondoTupla = BackColor;
        }

        public void Ocultar() {
            Hide();
        }

        public void Cerrar() {
            Dispose();
        }

        private Color ObtenerColorFondoTupla(EstadoPedidoEnum estado) {
            return estado switch {
                EstadoPedidoEnum.Pendiente => ContextoAplicacion.ColorAdvertenciaTupla,
                EstadoPedidoEnum.Cancelado => ContextoAplicacion.ColorErrorTupla,
                _ => BackColor
            };
        }
    }
}