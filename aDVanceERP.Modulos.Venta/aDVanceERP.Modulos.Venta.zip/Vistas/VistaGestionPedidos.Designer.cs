﻿using Guna.UI2.WinForms;

using System.ComponentModel;

namespace aDVanceERP.Modulos.Venta.Vistas {
    partial class VistaGestionPedidos {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            components = new Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            ComponentResourceManager resources = new ComponentResourceManager(typeof(VistaGestionPedidos));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            formatoBase = new Guna2BorderlessForm(components);
            layoutVista = new TableLayoutPanel();
            layoutSeparadores = new TableLayoutPanel();
            separador2 = new Guna2Separator();
            separador1 = new Guna2Separator();
            layoutHerramientas = new TableLayoutPanel();
            layoutFechaHasta = new TableLayoutPanel();
            fieldFiltroBusquedaFechaHasta = new Guna2DateTimePicker();
            fieldTextoHasta = new Label();
            fieldFiltroBusqueda = new Guna2ComboBox();
            panelDatosComplementariosBusqueda = new Panel();
            fieldCriterioBusqueda = new Guna2TextBox();
            layoutFechaDesde = new TableLayoutPanel();
            fieldFiltroBusquedaFechaDesde = new Guna2DateTimePicker();
            fieldTextoDesde = new Label();
            layoutTituloHerramientas = new TableLayoutPanel();
            fieldTituloRangoFechaVentas = new Label();
            fieldTituloFiltrosBusqueda = new Label();
            panelBotonesGestion = new Panel();
            btnHabilitarDeshabilitarPedido = new Guna2Button();
            btnRegistrarPedidoManual = new Guna2Button();
            layoutEncabezadosTabla = new TableLayoutPanel();
            fieldDireccionEntrega = new Label();
            fieldTituloFechaEntrega = new Label();
            fieldTituloId = new Label();
            fieldTituloNombreCliente = new Label();
            fieldTituloFecha = new Label();
            fieldTituloImporteTotal = new Label();
            fieldTituloEstado = new Label();
            layoutTitulo = new TableLayoutPanel();
            fieldTitulo = new Label();
            fieldIcono = new PictureBox();
            fieldSubtitulo = new Label();
            contenedorVistas = new Panel();
            layoutControlesTabla = new TableLayoutPanel();
            btnPaginaAnterior = new Guna2Button();
            btnPrimeraPagina = new Guna2Button();
            btnPaginaSiguiente = new Guna2Button();
            btnUltimaPagina = new Guna2Button();
            btnSincronizarDatos = new Guna2Button();
            fieldPaginaActual = new Label();
            fieldPaginasTotales = new Label();
            layoutPago = new TableLayoutPanel();
            symbolPeso = new Label();
            fieldTotalVenta = new Label();
            layoutVista.SuspendLayout();
            layoutSeparadores.SuspendLayout();
            layoutHerramientas.SuspendLayout();
            layoutFechaHasta.SuspendLayout();
            panelDatosComplementariosBusqueda.SuspendLayout();
            layoutFechaDesde.SuspendLayout();
            layoutTituloHerramientas.SuspendLayout();
            panelBotonesGestion.SuspendLayout();
            layoutEncabezadosTabla.SuspendLayout();
            layoutTitulo.SuspendLayout();
            ((ISupportInitialize) fieldIcono).BeginInit();
            layoutControlesTabla.SuspendLayout();
            layoutPago.SuspendLayout();
            SuspendLayout();
            // 
            // formatoBase
            // 
            formatoBase.ContainerControl = this;
            formatoBase.DockIndicatorTransparencyValue = 0.6D;
            formatoBase.DragForm = false;
            formatoBase.HasFormShadow = false;
            formatoBase.TransparentWhileDrag = true;
            // 
            // layoutVista
            // 
            layoutVista.BackColor = Color.White;
            layoutVista.ColumnCount = 4;
            layoutVista.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            layoutVista.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 30F));
            layoutVista.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutVista.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            layoutVista.Controls.Add(layoutSeparadores, 2, 6);
            layoutVista.Controls.Add(layoutHerramientas, 2, 5);
            layoutVista.Controls.Add(layoutTituloHerramientas, 2, 4);
            layoutVista.Controls.Add(panelBotonesGestion, 2, 7);
            layoutVista.Controls.Add(layoutEncabezadosTabla, 2, 9);
            layoutVista.Controls.Add(layoutTitulo, 2, 1);
            layoutVista.Controls.Add(fieldIcono, 1, 1);
            layoutVista.Controls.Add(fieldSubtitulo, 2, 2);
            layoutVista.Controls.Add(contenedorVistas, 2, 11);
            layoutVista.Controls.Add(layoutControlesTabla, 2, 12);
            layoutVista.Dock = DockStyle.Fill;
            layoutVista.Location = new Point(0, 0);
            layoutVista.Margin = new Padding(1);
            layoutVista.Name = "layoutVista";
            layoutVista.RowCount = 14;
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 10F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 45F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 45F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 45F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 10F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 60F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 10F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));
            layoutVista.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            layoutVista.Size = new Size(1356, 608);
            layoutVista.TabIndex = 4;
            // 
            // layoutSeparadores
            // 
            layoutSeparadores.ColumnCount = 2;
            layoutSeparadores.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 440F));
            layoutSeparadores.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutSeparadores.Controls.Add(separador2, 1, 0);
            layoutSeparadores.Controls.Add(separador1, 0, 0);
            layoutSeparadores.Dock = DockStyle.Fill;
            layoutSeparadores.Location = new Point(50, 190);
            layoutSeparadores.Margin = new Padding(0);
            layoutSeparadores.Name = "layoutSeparadores";
            layoutSeparadores.RowCount = 1;
            layoutSeparadores.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutSeparadores.Size = new Size(1286, 20);
            layoutSeparadores.TabIndex = 41;
            // 
            // separador2
            // 
            separador2.Dock = DockStyle.Fill;
            separador2.FillColor = Color.Gainsboro;
            separador2.Location = new Point(443, 3);
            separador2.Name = "separador2";
            separador2.Size = new Size(840, 14);
            separador2.TabIndex = 39;
            // 
            // separador1
            // 
            separador1.Dock = DockStyle.Fill;
            separador1.FillColor = Color.Gainsboro;
            separador1.Location = new Point(3, 3);
            separador1.Name = "separador1";
            separador1.Size = new Size(434, 14);
            separador1.TabIndex = 38;
            // 
            // layoutHerramientas
            // 
            layoutHerramientas.ColumnCount = 5;
            layoutHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220F));
            layoutHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220F));
            layoutHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250F));
            layoutHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250F));
            layoutHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutHerramientas.Controls.Add(layoutFechaHasta, 1, 0);
            layoutHerramientas.Controls.Add(fieldFiltroBusqueda, 2, 0);
            layoutHerramientas.Controls.Add(panelDatosComplementariosBusqueda, 3, 0);
            layoutHerramientas.Controls.Add(layoutFechaDesde, 0, 0);
            layoutHerramientas.Dock = DockStyle.Fill;
            layoutHerramientas.Location = new Point(50, 145);
            layoutHerramientas.Margin = new Padding(0);
            layoutHerramientas.Name = "layoutHerramientas";
            layoutHerramientas.RowCount = 1;
            layoutHerramientas.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutHerramientas.Size = new Size(1286, 45);
            layoutHerramientas.TabIndex = 38;
            // 
            // layoutFechaHasta
            // 
            layoutFechaHasta.ColumnCount = 2;
            layoutFechaHasta.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 57F));
            layoutFechaHasta.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutFechaHasta.Controls.Add(fieldFiltroBusquedaFechaHasta, 0, 0);
            layoutFechaHasta.Controls.Add(fieldTextoHasta, 0, 0);
            layoutFechaHasta.Dock = DockStyle.Fill;
            layoutFechaHasta.Location = new Point(220, 0);
            layoutFechaHasta.Margin = new Padding(0);
            layoutFechaHasta.Name = "layoutFechaHasta";
            layoutFechaHasta.RowCount = 1;
            layoutFechaHasta.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutFechaHasta.Size = new Size(220, 45);
            layoutFechaHasta.TabIndex = 30;
            // 
            // fieldFiltroBusquedaFechaHasta
            // 
            fieldFiltroBusquedaFechaHasta.BackColor = Color.White;
            fieldFiltroBusquedaFechaHasta.BorderColor = Color.Gainsboro;
            fieldFiltroBusquedaFechaHasta.BorderRadius = 18;
            fieldFiltroBusquedaFechaHasta.BorderThickness = 1;
            fieldFiltroBusquedaFechaHasta.Checked = true;
            fieldFiltroBusquedaFechaHasta.CheckedState.BorderColor = Color.Gainsboro;
            fieldFiltroBusquedaFechaHasta.CheckedState.FillColor = Color.White;
            fieldFiltroBusquedaFechaHasta.CheckedState.ForeColor = Color.Black;
            fieldFiltroBusquedaFechaHasta.CustomFormat = "yyyy-MM-dd";
            fieldFiltroBusquedaFechaHasta.CustomizableEdges = customizableEdges1;
            fieldFiltroBusquedaFechaHasta.Dock = DockStyle.Fill;
            fieldFiltroBusquedaFechaHasta.FillColor = Color.White;
            fieldFiltroBusquedaFechaHasta.Font = new Font("Segoe UI", 11.25F);
            fieldFiltroBusquedaFechaHasta.ForeColor = Color.Black;
            fieldFiltroBusquedaFechaHasta.Format = DateTimePickerFormat.Custom;
            fieldFiltroBusquedaFechaHasta.Location = new Point(62, 5);
            fieldFiltroBusquedaFechaHasta.Margin = new Padding(5);
            fieldFiltroBusquedaFechaHasta.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            fieldFiltroBusquedaFechaHasta.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            fieldFiltroBusquedaFechaHasta.Name = "fieldFiltroBusquedaFechaHasta";
            fieldFiltroBusquedaFechaHasta.ShadowDecoration.CustomizableEdges = customizableEdges2;
            fieldFiltroBusquedaFechaHasta.Size = new Size(153, 35);
            fieldFiltroBusquedaFechaHasta.TabIndex = 26;
            fieldFiltroBusquedaFechaHasta.Value = new DateTime(2025, 2, 20, 21, 31, 28, 166);
            // 
            // fieldTextoHasta
            // 
            fieldTextoHasta.Dock = DockStyle.Fill;
            fieldTextoHasta.Font = new Font("Segoe UI", 11.25F);
            fieldTextoHasta.ForeColor = Color.Black;
            fieldTextoHasta.ImeMode = ImeMode.NoControl;
            fieldTextoHasta.Location = new Point(5, 5);
            fieldTextoHasta.Margin = new Padding(5, 5, 1, 1);
            fieldTextoHasta.Name = "fieldTextoHasta";
            fieldTextoHasta.Size = new Size(51, 39);
            fieldTextoHasta.TabIndex = 3;
            fieldTextoHasta.Text = "Hasta";
            fieldTextoHasta.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // fieldFiltroBusqueda
            // 
            fieldFiltroBusqueda.Animated = true;
            fieldFiltroBusqueda.BackColor = Color.Transparent;
            fieldFiltroBusqueda.BorderColor = Color.Gainsboro;
            fieldFiltroBusqueda.BorderRadius = 16;
            fieldFiltroBusqueda.CustomizableEdges = customizableEdges3;
            fieldFiltroBusqueda.Dock = DockStyle.Fill;
            fieldFiltroBusqueda.DrawMode = DrawMode.OwnerDrawFixed;
            fieldFiltroBusqueda.DropDownStyle = ComboBoxStyle.DropDownList;
            fieldFiltroBusqueda.FocusedColor = Color.Gainsboro;
            fieldFiltroBusqueda.FocusedState.BorderColor = Color.Gainsboro;
            fieldFiltroBusqueda.Font = new Font("Segoe UI", 11.25F);
            fieldFiltroBusqueda.ForeColor = Color.Black;
            fieldFiltroBusqueda.ItemHeight = 29;
            fieldFiltroBusqueda.Location = new Point(445, 5);
            fieldFiltroBusqueda.Margin = new Padding(5);
            fieldFiltroBusqueda.Name = "fieldFiltroBusqueda";
            fieldFiltroBusqueda.ShadowDecoration.CustomizableEdges = customizableEdges4;
            fieldFiltroBusqueda.Size = new Size(240, 35);
            fieldFiltroBusqueda.TabIndex = 27;
            fieldFiltroBusqueda.TextOffset = new Point(10, 0);
            // 
            // panelDatosComplementariosBusqueda
            // 
            panelDatosComplementariosBusqueda.Controls.Add(fieldCriterioBusqueda);
            panelDatosComplementariosBusqueda.Dock = DockStyle.Fill;
            panelDatosComplementariosBusqueda.Location = new Point(695, 5);
            panelDatosComplementariosBusqueda.Margin = new Padding(5);
            panelDatosComplementariosBusqueda.Name = "panelDatosComplementariosBusqueda";
            panelDatosComplementariosBusqueda.Size = new Size(240, 35);
            panelDatosComplementariosBusqueda.TabIndex = 28;
            // 
            // fieldCriterioBusqueda
            // 
            fieldCriterioBusqueda.Animated = true;
            fieldCriterioBusqueda.BackColor = Color.FromArgb(  254,   254,   253);
            fieldCriterioBusqueda.BorderColor = Color.Gainsboro;
            fieldCriterioBusqueda.BorderRadius = 18;
            fieldCriterioBusqueda.Cursor = Cursors.IBeam;
            fieldCriterioBusqueda.CustomizableEdges = customizableEdges5;
            fieldCriterioBusqueda.DefaultText = "";
            fieldCriterioBusqueda.DisabledState.BorderColor = Color.White;
            fieldCriterioBusqueda.DisabledState.ForeColor = Color.DimGray;
            fieldCriterioBusqueda.DisabledState.PlaceholderForeColor = Color.DimGray;
            fieldCriterioBusqueda.Dock = DockStyle.Fill;
            fieldCriterioBusqueda.Font = new Font("Segoe UI", 11.25F);
            fieldCriterioBusqueda.ForeColor = Color.Black;
            fieldCriterioBusqueda.HoverState.BorderColor = Color.SandyBrown;
            fieldCriterioBusqueda.IconLeft = (Image) resources.GetObject("fieldCriterioBusqueda.IconLeft");
            fieldCriterioBusqueda.IconLeftOffset = new Point(10, 1);
            fieldCriterioBusqueda.IconRightOffset = new Point(10, 0);
            fieldCriterioBusqueda.Location = new Point(0, 0);
            fieldCriterioBusqueda.Margin = new Padding(5);
            fieldCriterioBusqueda.Name = "fieldCriterioBusqueda";
            fieldCriterioBusqueda.PasswordChar = '\0';
            fieldCriterioBusqueda.PlaceholderForeColor = Color.DimGray;
            fieldCriterioBusqueda.PlaceholderText = "Criterio de búsqueda";
            fieldCriterioBusqueda.SelectedText = "";
            fieldCriterioBusqueda.ShadowDecoration.CustomizableEdges = customizableEdges6;
            fieldCriterioBusqueda.Size = new Size(240, 35);
            fieldCriterioBusqueda.TabIndex = 9;
            fieldCriterioBusqueda.TextOffset = new Point(5, 0);
            fieldCriterioBusqueda.Visible = false;
            // 
            // layoutFechaDesde
            // 
            layoutFechaDesde.ColumnCount = 2;
            layoutFechaDesde.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 57F));
            layoutFechaDesde.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutFechaDesde.Controls.Add(fieldFiltroBusquedaFechaDesde, 0, 0);
            layoutFechaDesde.Controls.Add(fieldTextoDesde, 0, 0);
            layoutFechaDesde.Dock = DockStyle.Fill;
            layoutFechaDesde.Location = new Point(0, 0);
            layoutFechaDesde.Margin = new Padding(0);
            layoutFechaDesde.Name = "layoutFechaDesde";
            layoutFechaDesde.RowCount = 1;
            layoutFechaDesde.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutFechaDesde.Size = new Size(220, 45);
            layoutFechaDesde.TabIndex = 29;
            // 
            // fieldFiltroBusquedaFechaDesde
            // 
            fieldFiltroBusquedaFechaDesde.BackColor = Color.White;
            fieldFiltroBusquedaFechaDesde.BorderColor = Color.Gainsboro;
            fieldFiltroBusquedaFechaDesde.BorderRadius = 18;
            fieldFiltroBusquedaFechaDesde.BorderThickness = 1;
            fieldFiltroBusquedaFechaDesde.Checked = true;
            fieldFiltroBusquedaFechaDesde.CheckedState.BorderColor = Color.Gainsboro;
            fieldFiltroBusquedaFechaDesde.CheckedState.FillColor = Color.White;
            fieldFiltroBusquedaFechaDesde.CheckedState.ForeColor = Color.Black;
            fieldFiltroBusquedaFechaDesde.CustomFormat = "yyyy-MM-dd";
            fieldFiltroBusquedaFechaDesde.CustomizableEdges = customizableEdges7;
            fieldFiltroBusquedaFechaDesde.Dock = DockStyle.Fill;
            fieldFiltroBusquedaFechaDesde.FillColor = Color.White;
            fieldFiltroBusquedaFechaDesde.Font = new Font("Segoe UI", 11.25F);
            fieldFiltroBusquedaFechaDesde.ForeColor = Color.Black;
            fieldFiltroBusquedaFechaDesde.Format = DateTimePickerFormat.Custom;
            fieldFiltroBusquedaFechaDesde.Location = new Point(62, 5);
            fieldFiltroBusquedaFechaDesde.Margin = new Padding(5);
            fieldFiltroBusquedaFechaDesde.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            fieldFiltroBusquedaFechaDesde.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            fieldFiltroBusquedaFechaDesde.Name = "fieldFiltroBusquedaFechaDesde";
            fieldFiltroBusquedaFechaDesde.ShadowDecoration.CustomizableEdges = customizableEdges8;
            fieldFiltroBusquedaFechaDesde.Size = new Size(153, 35);
            fieldFiltroBusquedaFechaDesde.TabIndex = 26;
            fieldFiltroBusquedaFechaDesde.Value = new DateTime(2025, 2, 20, 21, 31, 28, 166);
            // 
            // fieldTextoDesde
            // 
            fieldTextoDesde.Dock = DockStyle.Fill;
            fieldTextoDesde.Font = new Font("Segoe UI", 11.25F);
            fieldTextoDesde.ForeColor = Color.Black;
            fieldTextoDesde.ImeMode = ImeMode.NoControl;
            fieldTextoDesde.Location = new Point(5, 5);
            fieldTextoDesde.Margin = new Padding(5, 5, 1, 1);
            fieldTextoDesde.Name = "fieldTextoDesde";
            fieldTextoDesde.Size = new Size(51, 39);
            fieldTextoDesde.TabIndex = 3;
            fieldTextoDesde.Text = "Desde";
            fieldTextoDesde.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // layoutTituloHerramientas
            // 
            layoutTituloHerramientas.ColumnCount = 4;
            layoutTituloHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 440F));
            layoutTituloHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250F));
            layoutTituloHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250F));
            layoutTituloHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutTituloHerramientas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            layoutTituloHerramientas.Controls.Add(fieldTituloRangoFechaVentas, 0, 0);
            layoutTituloHerramientas.Controls.Add(fieldTituloFiltrosBusqueda, 1, 0);
            layoutTituloHerramientas.Dock = DockStyle.Fill;
            layoutTituloHerramientas.Location = new Point(50, 110);
            layoutTituloHerramientas.Margin = new Padding(0);
            layoutTituloHerramientas.Name = "layoutTituloHerramientas";
            layoutTituloHerramientas.RowCount = 1;
            layoutTituloHerramientas.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutTituloHerramientas.Size = new Size(1286, 35);
            layoutTituloHerramientas.TabIndex = 37;
            // 
            // fieldTituloRangoFechaVentas
            // 
            fieldTituloRangoFechaVentas.Dock = DockStyle.Fill;
            fieldTituloRangoFechaVentas.Font = new Font("Segoe UI", 11.25F);
            fieldTituloRangoFechaVentas.ForeColor = Color.DimGray;
            fieldTituloRangoFechaVentas.Image = (Image) resources.GetObject("fieldTituloRangoFechaVentas.Image");
            fieldTituloRangoFechaVentas.ImageAlign = ContentAlignment.MiddleLeft;
            fieldTituloRangoFechaVentas.ImeMode = ImeMode.NoControl;
            fieldTituloRangoFechaVentas.Location = new Point(15, 5);
            fieldTituloRangoFechaVentas.Margin = new Padding(15, 5, 3, 3);
            fieldTituloRangoFechaVentas.Name = "fieldTituloRangoFechaVentas";
            fieldTituloRangoFechaVentas.Size = new Size(422, 27);
            fieldTituloRangoFechaVentas.TabIndex = 25;
            fieldTituloRangoFechaVentas.Text = "      Rango de fechas de los pedidos registrados :";
            fieldTituloRangoFechaVentas.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // fieldTituloFiltrosBusqueda
            // 
            fieldTituloFiltrosBusqueda.Dock = DockStyle.Fill;
            fieldTituloFiltrosBusqueda.Font = new Font("Segoe UI", 11.25F);
            fieldTituloFiltrosBusqueda.ForeColor = Color.DimGray;
            fieldTituloFiltrosBusqueda.Image = (Image) resources.GetObject("fieldTituloFiltrosBusqueda.Image");
            fieldTituloFiltrosBusqueda.ImageAlign = ContentAlignment.MiddleLeft;
            fieldTituloFiltrosBusqueda.ImeMode = ImeMode.NoControl;
            fieldTituloFiltrosBusqueda.Location = new Point(455, 5);
            fieldTituloFiltrosBusqueda.Margin = new Padding(15, 5, 3, 3);
            fieldTituloFiltrosBusqueda.Name = "fieldTituloFiltrosBusqueda";
            fieldTituloFiltrosBusqueda.Size = new Size(232, 27);
            fieldTituloFiltrosBusqueda.TabIndex = 24;
            fieldTituloFiltrosBusqueda.Text = "      Filtro de búsqueda :";
            fieldTituloFiltrosBusqueda.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // panelBotonesGestion
            // 
            panelBotonesGestion.Controls.Add(btnHabilitarDeshabilitarPedido);
            panelBotonesGestion.Controls.Add(btnRegistrarPedidoManual);
            panelBotonesGestion.Dock = DockStyle.Fill;
            panelBotonesGestion.Location = new Point(50, 210);
            panelBotonesGestion.Margin = new Padding(0);
            panelBotonesGestion.Name = "panelBotonesGestion";
            panelBotonesGestion.Padding = new Padding(3);
            panelBotonesGestion.Size = new Size(1286, 45);
            panelBotonesGestion.TabIndex = 38;
            // 
            // btnHabilitarDeshabilitarPedido
            // 
            btnHabilitarDeshabilitarPedido.Animated = true;
            btnHabilitarDeshabilitarPedido.BackColor = Color.White;
            btnHabilitarDeshabilitarPedido.BorderRadius = 18;
            btnHabilitarDeshabilitarPedido.CustomizableEdges = customizableEdges9;
            btnHabilitarDeshabilitarPedido.Dock = DockStyle.Left;
            btnHabilitarDeshabilitarPedido.FillColor = Color.PeachPuff;
            btnHabilitarDeshabilitarPedido.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnHabilitarDeshabilitarPedido.ForeColor = Color.Black;
            btnHabilitarDeshabilitarPedido.Image = (Image) resources.GetObject("btnHabilitarDeshabilitarPedido.Image");
            btnHabilitarDeshabilitarPedido.ImageOffset = new Point(-5, 0);
            btnHabilitarDeshabilitarPedido.Location = new Point(237, 3);
            btnHabilitarDeshabilitarPedido.Margin = new Padding(0);
            btnHabilitarDeshabilitarPedido.Name = "btnHabilitarDeshabilitarPedido";
            btnHabilitarDeshabilitarPedido.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnHabilitarDeshabilitarPedido.Size = new Size(272, 39);
            btnHabilitarDeshabilitarPedido.TabIndex = 11;
            btnHabilitarDeshabilitarPedido.Text = "Habilitar/Deshabilitar pedido";
            btnHabilitarDeshabilitarPedido.Visible = false;
            // 
            // btnRegistrarPedidoManual
            // 
            btnRegistrarPedidoManual.Animated = true;
            btnRegistrarPedidoManual.BackColor = Color.White;
            btnRegistrarPedidoManual.BorderRadius = 18;
            btnRegistrarPedidoManual.CustomizableEdges = customizableEdges11;
            btnRegistrarPedidoManual.Dock = DockStyle.Left;
            btnRegistrarPedidoManual.FillColor = Color.PeachPuff;
            btnRegistrarPedidoManual.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnRegistrarPedidoManual.ForeColor = Color.Black;
            btnRegistrarPedidoManual.Image = (Image) resources.GetObject("btnRegistrarPedidoManual.Image");
            btnRegistrarPedidoManual.ImageOffset = new Point(-5, 0);
            btnRegistrarPedidoManual.Location = new Point(3, 3);
            btnRegistrarPedidoManual.Margin = new Padding(0);
            btnRegistrarPedidoManual.Name = "btnRegistrarPedidoManual";
            btnRegistrarPedidoManual.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnRegistrarPedidoManual.Size = new Size(234, 39);
            btnRegistrarPedidoManual.TabIndex = 7;
            btnRegistrarPedidoManual.Text = "Registrar pedido manual";
            // 
            // layoutEncabezadosTabla
            // 
            layoutEncabezadosTabla.BackColor = Color.WhiteSmoke;
            layoutEncabezadosTabla.ColumnCount = 10;
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40F));
            layoutEncabezadosTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40F));
            layoutEncabezadosTabla.Controls.Add(fieldDireccionEntrega, 4, 0);
            layoutEncabezadosTabla.Controls.Add(fieldTituloFechaEntrega, 3, 0);
            layoutEncabezadosTabla.Controls.Add(fieldTituloId, 0, 0);
            layoutEncabezadosTabla.Controls.Add(fieldTituloNombreCliente, 2, 0);
            layoutEncabezadosTabla.Controls.Add(fieldTituloFecha, 1, 0);
            layoutEncabezadosTabla.Controls.Add(fieldTituloImporteTotal, 5, 0);
            layoutEncabezadosTabla.Controls.Add(fieldTituloEstado, 6, 0);
            layoutEncabezadosTabla.Dock = DockStyle.Fill;
            layoutEncabezadosTabla.Location = new Point(50, 265);
            layoutEncabezadosTabla.Margin = new Padding(0, 0, 0, 2);
            layoutEncabezadosTabla.Name = "layoutEncabezadosTabla";
            layoutEncabezadosTabla.RowCount = 1;
            layoutEncabezadosTabla.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutEncabezadosTabla.Size = new Size(1286, 58);
            layoutEncabezadosTabla.TabIndex = 19;
            // 
            // fieldDireccionEntrega
            // 
            fieldDireccionEntrega.Dock = DockStyle.Fill;
            fieldDireccionEntrega.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            fieldDireccionEntrega.ForeColor = Color.Black;
            fieldDireccionEntrega.ImeMode = ImeMode.NoControl;
            fieldDireccionEntrega.Location = new Point(603, 1);
            fieldDireccionEntrega.Margin = new Padding(1);
            fieldDireccionEntrega.Name = "fieldDireccionEntrega";
            fieldDireccionEntrega.Size = new Size(301, 56);
            fieldDireccionEntrega.TabIndex = 15;
            fieldDireccionEntrega.Text = "Dirección de entrega";
            fieldDireccionEntrega.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // fieldTituloFechaEntrega
            // 
            fieldTituloFechaEntrega.Dock = DockStyle.Fill;
            fieldTituloFechaEntrega.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            fieldTituloFechaEntrega.ForeColor = Color.Black;
            fieldTituloFechaEntrega.ImeMode = ImeMode.NoControl;
            fieldTituloFechaEntrega.Location = new Point(483, 1);
            fieldTituloFechaEntrega.Margin = new Padding(1);
            fieldTituloFechaEntrega.Name = "fieldTituloFechaEntrega";
            fieldTituloFechaEntrega.Size = new Size(118, 56);
            fieldTituloFechaEntrega.TabIndex = 15;
            fieldTituloFechaEntrega.Text = "Fecha de entrega";
            fieldTituloFechaEntrega.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // fieldTituloId
            // 
            fieldTituloId.Dock = DockStyle.Fill;
            fieldTituloId.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            fieldTituloId.ForeColor = Color.Black;
            fieldTituloId.ImeMode = ImeMode.NoControl;
            fieldTituloId.Location = new Point(1, 1);
            fieldTituloId.Margin = new Padding(1);
            fieldTituloId.Name = "fieldTituloId";
            fieldTituloId.Size = new Size(158, 56);
            fieldTituloId.TabIndex = 14;
            fieldTituloId.Text = "Código";
            fieldTituloId.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // fieldTituloNombreCliente
            // 
            fieldTituloNombreCliente.Dock = DockStyle.Fill;
            fieldTituloNombreCliente.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            fieldTituloNombreCliente.ForeColor = Color.Black;
            fieldTituloNombreCliente.ImeMode = ImeMode.NoControl;
            fieldTituloNombreCliente.Location = new Point(281, 1);
            fieldTituloNombreCliente.Margin = new Padding(1);
            fieldTituloNombreCliente.Name = "fieldTituloNombreCliente";
            fieldTituloNombreCliente.Size = new Size(200, 56);
            fieldTituloNombreCliente.TabIndex = 15;
            fieldTituloNombreCliente.Text = "Cliente";
            fieldTituloNombreCliente.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // fieldTituloFecha
            // 
            fieldTituloFecha.Dock = DockStyle.Fill;
            fieldTituloFecha.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            fieldTituloFecha.ForeColor = Color.Black;
            fieldTituloFecha.ImeMode = ImeMode.NoControl;
            fieldTituloFecha.Location = new Point(161, 1);
            fieldTituloFecha.Margin = new Padding(1);
            fieldTituloFecha.Name = "fieldTituloFecha";
            fieldTituloFecha.Size = new Size(118, 56);
            fieldTituloFecha.TabIndex = 16;
            fieldTituloFecha.Text = "Fecha";
            fieldTituloFecha.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // fieldTituloImporteTotal
            // 
            fieldTituloImporteTotal.Dock = DockStyle.Fill;
            fieldTituloImporteTotal.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            fieldTituloImporteTotal.ForeColor = Color.Black;
            fieldTituloImporteTotal.ImeMode = ImeMode.NoControl;
            fieldTituloImporteTotal.Location = new Point(906, 1);
            fieldTituloImporteTotal.Margin = new Padding(1);
            fieldTituloImporteTotal.Name = "fieldTituloImporteTotal";
            fieldTituloImporteTotal.Size = new Size(128, 56);
            fieldTituloImporteTotal.TabIndex = 19;
            fieldTituloImporteTotal.Text = "Importe total";
            fieldTituloImporteTotal.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // fieldTituloEstado
            // 
            fieldTituloEstado.Dock = DockStyle.Fill;
            fieldTituloEstado.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            fieldTituloEstado.ForeColor = Color.Black;
            fieldTituloEstado.ImeMode = ImeMode.NoControl;
            fieldTituloEstado.Location = new Point(1036, 1);
            fieldTituloEstado.Margin = new Padding(1);
            fieldTituloEstado.Name = "fieldTituloEstado";
            fieldTituloEstado.Size = new Size(128, 56);
            fieldTituloEstado.TabIndex = 20;
            fieldTituloEstado.Text = "Estado";
            fieldTituloEstado.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // layoutTitulo
            // 
            layoutTitulo.ColumnCount = 2;
            layoutTitulo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutTitulo.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 50F));
            layoutTitulo.Controls.Add(fieldTitulo, 0, 0);
            layoutTitulo.Dock = DockStyle.Fill;
            layoutTitulo.Location = new Point(50, 10);
            layoutTitulo.Margin = new Padding(0);
            layoutTitulo.Name = "layoutTitulo";
            layoutTitulo.RowCount = 1;
            layoutTitulo.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutTitulo.Size = new Size(1286, 45);
            layoutTitulo.TabIndex = 14;
            // 
            // fieldTitulo
            // 
            fieldTitulo.Dock = DockStyle.Fill;
            fieldTitulo.Font = new Font("Segoe UI", 20.25F);
            fieldTitulo.ForeColor = Color.Black;
            fieldTitulo.ImeMode = ImeMode.NoControl;
            fieldTitulo.Location = new Point(3, 0);
            fieldTitulo.Name = "fieldTitulo";
            fieldTitulo.Size = new Size(1230, 45);
            fieldTitulo.TabIndex = 3;
            fieldTitulo.Text = "Gestión para pedidos";
            fieldTitulo.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // fieldIcono
            // 
            fieldIcono.BackgroundImage = (Image) resources.GetObject("fieldIcono.BackgroundImage");
            fieldIcono.BackgroundImageLayout = ImageLayout.Center;
            fieldIcono.Dock = DockStyle.Fill;
            fieldIcono.Location = new Point(20, 16);
            fieldIcono.Margin = new Padding(0, 6, 0, 0);
            fieldIcono.Name = "fieldIcono";
            fieldIcono.Size = new Size(30, 39);
            fieldIcono.TabIndex = 0;
            fieldIcono.TabStop = false;
            // 
            // fieldSubtitulo
            // 
            fieldSubtitulo.Dock = DockStyle.Fill;
            fieldSubtitulo.Font = new Font("Segoe UI", 11.25F);
            fieldSubtitulo.ForeColor = Color.Gray;
            fieldSubtitulo.ImeMode = ImeMode.NoControl;
            fieldSubtitulo.Location = new Point(55, 60);
            fieldSubtitulo.Margin = new Padding(5, 5, 1, 1);
            fieldSubtitulo.Name = "fieldSubtitulo";
            fieldSubtitulo.Size = new Size(1280, 29);
            fieldSubtitulo.TabIndex = 2;
            fieldSubtitulo.Text = "Registro, edición y búsqueda de pedidos.";
            // 
            // contenedorVistas
            // 
            contenedorVistas.Dock = DockStyle.Fill;
            contenedorVistas.Location = new Point(50, 335);
            contenedorVistas.Margin = new Padding(0);
            contenedorVistas.Name = "contenedorVistas";
            contenedorVistas.Size = new Size(1286, 218);
            contenedorVistas.TabIndex = 13;
            // 
            // layoutControlesTabla
            // 
            layoutControlesTabla.BackColor = Color.WhiteSmoke;
            layoutControlesTabla.ColumnCount = 13;
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 35F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 35F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 10F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 10F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 35F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 35F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 10F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 35F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 10F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250F));
            layoutControlesTabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutControlesTabla.Controls.Add(btnPaginaAnterior, 1, 0);
            layoutControlesTabla.Controls.Add(btnPrimeraPagina, 0, 0);
            layoutControlesTabla.Controls.Add(btnPaginaSiguiente, 6, 0);
            layoutControlesTabla.Controls.Add(btnUltimaPagina, 7, 0);
            layoutControlesTabla.Controls.Add(btnSincronizarDatos, 9, 0);
            layoutControlesTabla.Controls.Add(fieldPaginaActual, 3, 0);
            layoutControlesTabla.Controls.Add(fieldPaginasTotales, 4, 0);
            layoutControlesTabla.Dock = DockStyle.Fill;
            layoutControlesTabla.Location = new Point(50, 553);
            layoutControlesTabla.Margin = new Padding(0);
            layoutControlesTabla.Name = "layoutControlesTabla";
            layoutControlesTabla.RowCount = 1;
            layoutControlesTabla.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layoutControlesTabla.Size = new Size(1286, 35);
            layoutControlesTabla.TabIndex = 17;
            // 
            // btnPaginaAnterior
            // 
            btnPaginaAnterior.Animated = true;
            btnPaginaAnterior.BackColor = Color.WhiteSmoke;
            btnPaginaAnterior.CheckedState.BorderColor = Color.WhiteSmoke;
            btnPaginaAnterior.CheckedState.FillColor = Color.WhiteSmoke;
            btnPaginaAnterior.CustomImages.Image = (Image) resources.GetObject("resource.Image");
            btnPaginaAnterior.CustomImages.ImageAlign = HorizontalAlignment.Center;
            btnPaginaAnterior.CustomImages.ImageSize = new Size(24, 24);
            btnPaginaAnterior.CustomizableEdges = customizableEdges13;
            btnPaginaAnterior.Dock = DockStyle.Fill;
            btnPaginaAnterior.FillColor = Color.WhiteSmoke;
            btnPaginaAnterior.Font = new Font("Segoe UI", 9F);
            btnPaginaAnterior.ForeColor = Color.White;
            btnPaginaAnterior.HoverState.BorderColor = Color.FromArgb(  245,   245,   245);
            btnPaginaAnterior.HoverState.FillColor = Color.WhiteSmoke;
            btnPaginaAnterior.ImageSize = new Size(24, 24);
            btnPaginaAnterior.Location = new Point(36, 1);
            btnPaginaAnterior.Margin = new Padding(1);
            btnPaginaAnterior.Name = "btnPaginaAnterior";
            btnPaginaAnterior.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnPaginaAnterior.Size = new Size(33, 33);
            btnPaginaAnterior.TabIndex = 1;
            // 
            // btnPrimeraPagina
            // 
            btnPrimeraPagina.Animated = true;
            btnPrimeraPagina.BackColor = Color.WhiteSmoke;
            btnPrimeraPagina.CheckedState.BorderColor = Color.WhiteSmoke;
            btnPrimeraPagina.CheckedState.FillColor = Color.WhiteSmoke;
            btnPrimeraPagina.CustomImages.Image = (Image) resources.GetObject("resource.Image1");
            btnPrimeraPagina.CustomImages.ImageAlign = HorizontalAlignment.Center;
            btnPrimeraPagina.CustomImages.ImageSize = new Size(24, 24);
            btnPrimeraPagina.CustomizableEdges = customizableEdges15;
            btnPrimeraPagina.Dock = DockStyle.Fill;
            btnPrimeraPagina.FillColor = Color.WhiteSmoke;
            btnPrimeraPagina.Font = new Font("Segoe UI", 9F);
            btnPrimeraPagina.ForeColor = Color.White;
            btnPrimeraPagina.HoverState.BorderColor = Color.FromArgb(  245,   245,   245);
            btnPrimeraPagina.HoverState.FillColor = Color.WhiteSmoke;
            btnPrimeraPagina.ImageSize = new Size(24, 24);
            btnPrimeraPagina.Location = new Point(1, 1);
            btnPrimeraPagina.Margin = new Padding(1);
            btnPrimeraPagina.Name = "btnPrimeraPagina";
            btnPrimeraPagina.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnPrimeraPagina.Size = new Size(33, 33);
            btnPrimeraPagina.TabIndex = 0;
            // 
            // btnPaginaSiguiente
            // 
            btnPaginaSiguiente.Animated = true;
            btnPaginaSiguiente.BackColor = Color.WhiteSmoke;
            btnPaginaSiguiente.CheckedState.BorderColor = Color.WhiteSmoke;
            btnPaginaSiguiente.CheckedState.FillColor = Color.WhiteSmoke;
            btnPaginaSiguiente.CustomImages.Image = (Image) resources.GetObject("resource.Image2");
            btnPaginaSiguiente.CustomImages.ImageAlign = HorizontalAlignment.Center;
            btnPaginaSiguiente.CustomImages.ImageSize = new Size(24, 24);
            btnPaginaSiguiente.CustomizableEdges = customizableEdges17;
            btnPaginaSiguiente.Dock = DockStyle.Fill;
            btnPaginaSiguiente.FillColor = Color.WhiteSmoke;
            btnPaginaSiguiente.Font = new Font("Segoe UI", 9F);
            btnPaginaSiguiente.ForeColor = Color.White;
            btnPaginaSiguiente.HoverState.BorderColor = Color.FromArgb(  245,   245,   245);
            btnPaginaSiguiente.HoverState.FillColor = Color.WhiteSmoke;
            btnPaginaSiguiente.ImageSize = new Size(24, 24);
            btnPaginaSiguiente.Location = new Point(311, 1);
            btnPaginaSiguiente.Margin = new Padding(1);
            btnPaginaSiguiente.Name = "btnPaginaSiguiente";
            btnPaginaSiguiente.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnPaginaSiguiente.Size = new Size(33, 33);
            btnPaginaSiguiente.TabIndex = 2;
            // 
            // btnUltimaPagina
            // 
            btnUltimaPagina.Animated = true;
            btnUltimaPagina.BackColor = Color.WhiteSmoke;
            btnUltimaPagina.CheckedState.BorderColor = Color.WhiteSmoke;
            btnUltimaPagina.CheckedState.FillColor = Color.WhiteSmoke;
            btnUltimaPagina.CustomImages.Image = (Image) resources.GetObject("resource.Image3");
            btnUltimaPagina.CustomImages.ImageAlign = HorizontalAlignment.Center;
            btnUltimaPagina.CustomImages.ImageSize = new Size(24, 24);
            btnUltimaPagina.CustomizableEdges = customizableEdges19;
            btnUltimaPagina.Dock = DockStyle.Fill;
            btnUltimaPagina.FillColor = Color.WhiteSmoke;
            btnUltimaPagina.Font = new Font("Segoe UI", 9F);
            btnUltimaPagina.ForeColor = Color.White;
            btnUltimaPagina.HoverState.BorderColor = Color.FromArgb(  245,   245,   245);
            btnUltimaPagina.HoverState.FillColor = Color.WhiteSmoke;
            btnUltimaPagina.ImageSize = new Size(24, 24);
            btnUltimaPagina.Location = new Point(346, 1);
            btnUltimaPagina.Margin = new Padding(1);
            btnUltimaPagina.Name = "btnUltimaPagina";
            btnUltimaPagina.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnUltimaPagina.Size = new Size(33, 33);
            btnUltimaPagina.TabIndex = 3;
            // 
            // btnSincronizarDatos
            // 
            btnSincronizarDatos.Animated = true;
            btnSincronizarDatos.BackColor = Color.WhiteSmoke;
            btnSincronizarDatos.CheckedState.BorderColor = Color.WhiteSmoke;
            btnSincronizarDatos.CheckedState.FillColor = Color.WhiteSmoke;
            btnSincronizarDatos.CustomImages.Image = (Image) resources.GetObject("resource.Image4");
            btnSincronizarDatos.CustomImages.ImageAlign = HorizontalAlignment.Center;
            btnSincronizarDatos.CustomImages.ImageSize = new Size(24, 24);
            btnSincronizarDatos.CustomizableEdges = customizableEdges21;
            btnSincronizarDatos.Dock = DockStyle.Fill;
            btnSincronizarDatos.FillColor = Color.WhiteSmoke;
            btnSincronizarDatos.Font = new Font("Segoe UI", 9F);
            btnSincronizarDatos.ForeColor = Color.White;
            btnSincronizarDatos.HoverState.BorderColor = Color.FromArgb(  245,   245,   245);
            btnSincronizarDatos.HoverState.FillColor = Color.WhiteSmoke;
            btnSincronizarDatos.ImageSize = new Size(24, 24);
            btnSincronizarDatos.Location = new Point(391, 1);
            btnSincronizarDatos.Margin = new Padding(1);
            btnSincronizarDatos.Name = "btnSincronizarDatos";
            btnSincronizarDatos.ShadowDecoration.CustomizableEdges = customizableEdges22;
            btnSincronizarDatos.Size = new Size(33, 33);
            btnSincronizarDatos.TabIndex = 4;
            // 
            // fieldPaginaActual
            // 
            fieldPaginaActual.Dock = DockStyle.Fill;
            fieldPaginaActual.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            fieldPaginaActual.ForeColor = Color.Black;
            fieldPaginaActual.ImeMode = ImeMode.NoControl;
            fieldPaginaActual.Location = new Point(81, 1);
            fieldPaginaActual.Margin = new Padding(1, 1, 0, 1);
            fieldPaginaActual.Name = "fieldPaginaActual";
            fieldPaginaActual.Size = new Size(119, 33);
            fieldPaginaActual.TabIndex = 5;
            fieldPaginaActual.Text = "Página 1";
            fieldPaginaActual.TextAlign = ContentAlignment.MiddleRight;
            // 
            // fieldPaginasTotales
            // 
            fieldPaginasTotales.Dock = DockStyle.Fill;
            fieldPaginasTotales.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            fieldPaginasTotales.ForeColor = Color.Black;
            fieldPaginasTotales.ImeMode = ImeMode.NoControl;
            fieldPaginasTotales.Location = new Point(200, 1);
            fieldPaginasTotales.Margin = new Padding(0, 1, 1, 1);
            fieldPaginasTotales.Name = "fieldPaginasTotales";
            fieldPaginasTotales.Size = new Size(99, 33);
            fieldPaginasTotales.TabIndex = 6;
            fieldPaginasTotales.Text = "de 1";
            fieldPaginasTotales.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // layoutPago
            // 
            layoutPago.ColumnCount = 4;
            layoutPago.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutPago.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110F));
            layoutPago.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            layoutPago.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110F));
            layoutPago.Controls.Add(symbolPeso, 0, 0);
            layoutPago.Location = new Point(0, 0);
            layoutPago.Name = "layoutPago";
            layoutPago.RowCount = 1;
            layoutPago.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            layoutPago.Size = new Size(200, 100);
            layoutPago.TabIndex = 0;
            // 
            // symbolPeso
            // 
            symbolPeso.Dock = DockStyle.Fill;
            symbolPeso.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            symbolPeso.ForeColor = Color.Black;
            symbolPeso.ImageAlign = ContentAlignment.MiddleLeft;
            symbolPeso.ImeMode = ImeMode.NoControl;
            symbolPeso.Location = new Point(3, 5);
            symbolPeso.Margin = new Padding(3, 5, 3, 3);
            symbolPeso.Name = "symbolPeso";
            symbolPeso.Size = new Size(1, 92);
            symbolPeso.TabIndex = 2;
            symbolPeso.Text = "$";
            symbolPeso.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // fieldTotalVenta
            // 
            fieldTotalVenta.Dock = DockStyle.Fill;
            fieldTotalVenta.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            fieldTotalVenta.ForeColor = Color.Black;
            fieldTotalVenta.ImageAlign = ContentAlignment.MiddleLeft;
            fieldTotalVenta.ImeMode = ImeMode.NoControl;
            fieldTotalVenta.Location = new Point(15, 5);
            fieldTotalVenta.Margin = new Padding(15, 5, 3, 3);
            fieldTotalVenta.Name = "fieldTotalVenta";
            fieldTotalVenta.Size = new Size(92, 37);
            fieldTotalVenta.TabIndex = 1;
            fieldTotalVenta.Text = "0";
            fieldTotalVenta.TextAlign = ContentAlignment.MiddleRight;
            // 
            // VistaGestionPedidos
            // 
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(1356, 608);
            Controls.Add(layoutVista);
            Font = new Font("Segoe UI", 10.8F);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "VistaGestionPedidos";
            ShowIcon = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            Text = "VistGestionProveedor";
            layoutVista.ResumeLayout(false);
            layoutSeparadores.ResumeLayout(false);
            layoutHerramientas.ResumeLayout(false);
            layoutFechaHasta.ResumeLayout(false);
            panelDatosComplementariosBusqueda.ResumeLayout(false);
            layoutFechaDesde.ResumeLayout(false);
            layoutTituloHerramientas.ResumeLayout(false);
            panelBotonesGestion.ResumeLayout(false);
            layoutEncabezadosTabla.ResumeLayout(false);
            layoutTitulo.ResumeLayout(false);
            ((ISupportInitialize) fieldIcono).EndInit();
            layoutControlesTabla.ResumeLayout(false);
            layoutPago.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Guna2BorderlessForm formatoBase;
        private TableLayoutPanel layoutVista;
        private TableLayoutPanel layoutTitulo;
        private Label fieldTitulo;
        private PictureBox fieldIcono;
        private Label fieldSubtitulo;
        private Label fieldTituloId;
        private Panel contenedorVistas;
        private TableLayoutPanel layoutControlesTabla;
        private Guna2Button btnPaginaAnterior;
        private Guna2Button btnPrimeraPagina;
        private Guna2Button btnPaginaSiguiente;
        private Guna2Button btnUltimaPagina;
        private Guna2Button btnSincronizarDatos;
        private Label fieldPaginaActual;
        private Label fieldPaginasTotales;
        private TableLayoutPanel layoutEncabezadosTabla;
        private Label fieldTituloNombreCliente;
        private Label fieldDireccionEntrega;
        private Label fieldTituloFechaEntrega;
        private Label fieldTituloFecha;
        private Panel panelBotonesGestion;
        private Guna2Button btnRegistrarPedidoManual;
        private TableLayoutPanel layoutTituloHerramientas;
        private Label fieldTituloFiltrosBusqueda;
        private TableLayoutPanel layoutHerramientas;
        private Guna2TextBox fieldCriterioBusqueda;
        private Guna2ComboBox fieldFiltroBusqueda;
        private Panel panelDatosComplementariosBusqueda;
        private TableLayoutPanel layoutSeparadores;
        private Guna2Separator separador1;
        private TableLayoutPanel layoutPago;
        private Label symbolPeso;
        private Label fieldTotalVenta;
        private Label fieldTituloImporteTotal;
        private Label fieldTituloEstado;
        private Guna2Button btnHabilitarDeshabilitarPedido;
        private Guna2Separator separador2;
        private TableLayoutPanel layoutFechaHasta;
        private Label fieldTextoHasta;
        private TableLayoutPanel layoutFechaDesde;
        private Label fieldTextoDesde;
        private Guna2DateTimePicker fieldFiltroBusquedaFechaHasta;
        private Guna2DateTimePicker fieldFiltroBusquedaFechaDesde;
        private Label fieldTituloRangoFechaVentas;
    }
}