﻿using aDVanceERP.Core.Eventos;
using aDVanceERP.Core.Infraestructura.Globales;
using aDVanceERP.Core.Modelos.Comun;
using aDVanceERP.Core.Presentadores.Comun.Interfaces;
using aDVanceERP.Core.Vistas.Comun;
using aDVanceERP.Core.Vistas.Comun.Interfaces;
using aDVanceERP.Desktop.Properties;
using aDVanceERP.Desktop.Vistas;

using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Suite;

namespace aDVanceERP.Desktop.Presentadores {
    public partial class PresentadorPrincipal : IPresentadorVistaPrincipal<IVistaPrincipal> {
        private readonly VistaCargaDatos _cargaDatos;

        public PresentadorPrincipal() {
            _cargaDatos = new VistaCargaDatos();

            Vista = new VistaPrincipal();
            Seguridad = new PresentadorContenedorSeguridad(Vista, new VistaContenedorSeguridad());
            Modulos = new PresentadorContenedorModulos(Vista, new VistaContenedorModulos());

            // Adicionar vistas al panel central
            Vista.PanelCentral.Registrar(Seguridad.Vista);
            Vista.PanelCentral.Registrar(Modulos.Vista);

            // Eventos de la vista principal
            ((Form) Vista).Shown += OnVistaPrincipalMostrada;

            // Eventos de seguridad
            AgregadorEventos.Suscribir("EventoUsuarioAutenticado", OnUsuarioAutenticado);
            AgregadorEventos.Suscribir("EventoSesionCerrada", OnSesionCerrada);

            // Adicionar vistas comunes
            InicializarVistasComunes();
        }

        public IVistaPrincipal Vista { get; }

        public IPresentadorVistaContenedorSeguridad<IVistaContenedorSeguridad> Seguridad { get; }

        public IPresentadorVistaContenedorModulos<IVistaContenedorModulos> Modulos { get; }

        private void OnVistaPrincipalMostrada(object? sender, EventArgs e) {
            Vista.BarraTitulo.OcultarTodos();
            Vista.BarraEstado.OcultarTodos();
            Vista.ModificarVisibilidadBotonesBarraTitulo(false);
            Vista.PanelCentral.Mostrar(nameof(VistaContenedorSeguridad));

            Seguridad.ConfiguracionBaseDatos.ConfiguracionCargada += async (s, args) => {
                var progreso = new Progress<(string texto, int porcentaje)>(datos => {
                    _cargaDatos.TextoProgreso = datos.texto;
                    _cargaDatos.ProgresoValor = datos.porcentaje;
                });

                _cargaDatos.TextoProgreso = " Cargando la aplicación...";
                _cargaDatos.Mostrar();
                
                await Task.Run(() => {
                    ((PresentadorContenedorModulos) Modulos).CargarModulosExtension(this, progreso);
                });

                _cargaDatos.Ocultar();
            };  
        }

        private void OnUsuarioAutenticado(string obj) {
            Vista.ModificarVisibilidadBotonesBarraTitulo(true);
            Vista.PanelCentral.Ocultar(nameof(VistaContenedorSeguridad));
            Vista.PanelCentral.Restaurar(nameof(VistaContenedorModulos));
            Vista.PanelCentral.Mostrar(nameof(VistaContenedorModulos));

            Modulos.Vista.ActualizarPortadaInicio($"{Program.Version}-beta", ContextoSeguridad.UsuarioAutenticado?.Nombre ?? "invitado");
        }

        private void OnSesionCerrada(string obj) {
            Vista.ModificarVisibilidadBotonesBarraTitulo(false);
            Vista.PanelCentral.Ocultar(nameof(VistaContenedorModulos));
            Vista.PanelCentral.Restaurar(nameof(VistaContenedorSeguridad));
            Vista.PanelCentral.Mostrar(nameof(VistaContenedorSeguridad));

            AgregadorEventos.Publicar("MostrarVistaAutenticacionUsuario", string.Empty);
        }

        private void InicializarVistasComunes() {
            // Módulos
            // Ubicaciones
            Modulos.Vista.PanelCentral.Registrar(new VistaGestionUbicaciones());
        }

        public void AdicionarBotonBarraTitulo(Guna2Button btnTitulo) {
            CustomizableEdges customizableEdges = new CustomizableEdges();

            btnTitulo.Animated = true;
            btnTitulo.BorderRadius = 5;
            btnTitulo.Cursor = Cursors.Hand;
            btnTitulo.CustomImages.ImageAlign = HorizontalAlignment.Center;
            btnTitulo.CustomImages.ImageSize = new Size(20, 20);
            btnTitulo.CustomizableEdges = customizableEdges;
            btnTitulo.FillColor = Color.WhiteSmoke;
            btnTitulo.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnTitulo.ForeColor = Color.White;
            btnTitulo.ImageSize = new Size(20, 20);
            btnTitulo.Margin = new Padding(1);
            btnTitulo.ShadowDecoration.CustomizableEdges = customizableEdges;
            btnTitulo.Size = new Size(50, 50);
            btnTitulo.TabIndex = Vista.BotonesTitulo.Controls.Count + 1;

            Vista.BotonesTitulo.Controls.Add(btnTitulo);
        }

        public void Dispose() {
            Modulos.Dispose();
            Seguridad.Dispose();
            Vista.Dispose();
        }
    }
}