﻿using aDVanceERP.Core.Modelos.Comun.Interfaces;

namespace aDVanceERP.Core.Modelos.Modulos.Inventario {
    public class Inventario : IEntidadBaseDatos {
        public Inventario() { }

        public Inventario(long id, long idProducto, long idAlmacen, decimal cantidad, decimal costoPromedio, decimal valorTotal, DateTime ultimaActualizacion) {
            Id = id;
            IdProducto = idProducto;
            IdAlmacen = idAlmacen;
            Cantidad = cantidad;
            CostoPromedio = costoPromedio;
            ValorTotal = valorTotal;
            UltimaActualizacion = ultimaActualizacion;
        }

        public long Id { get; set; }
        public long IdProducto { get; set; }
        public long IdAlmacen { get; set; }
        public decimal Cantidad { get; set; }
        public decimal CostoPromedio { get; set; }
        public decimal ValorTotal { get; set; }
        public DateTime UltimaActualizacion { get; set; }

        public override string ToString() {
            return $"{Id:000}, ID_ALM: {IdAlmacen}, ID_PROD: {IdProducto}, CANT: {Cantidad}, COST: {CostoPromedio}";
        }
    }

    public enum FiltroBusquedaInventario {
        Todos,
        Id,
        IdProducto,
        IdAlmacen
    }
}