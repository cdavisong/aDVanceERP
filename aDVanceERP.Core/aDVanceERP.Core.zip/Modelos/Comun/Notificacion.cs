﻿namespace aDVanceERP.Core.Modelos.Comun {
    public class Notificacion {
        public Notificacion() { }

        public Notificacion(string mensaje, TipoNotificacionEnum tipo) {
            Mensaje = mensaje;
            Tipo = tipo;
        }

        public string? Mensaje { get; set; }

        public int Duracion {
            get {
                var tiempoBase = 3000;
                var tiempoExtra = Mensaje?.Length * 50 ?? 1; // 50 milisegundos extra por caracter

                return tiempoBase + tiempoExtra;
            }
        }

        public TipoNotificacionEnum Tipo { get; set; }
    }
}