﻿// ============================================================
//  aDVancePOS.Mobile — JsonContexto
//  Archivo: JsonContexto.cs
// ============================================================

// Modelos catálogo
using aDVancePOS.Mobile.Servicios;

using System.Text.Json.Serialization;

// Namespace igual al del resto de la app móvil
namespace aDVancePOS.Mobile.Modelos {

    [JsonSerializable(typeof(CatalogoJson))]
    [JsonSerializable(typeof(CatalogoMeta))]
    [JsonSerializable(typeof(List<ProductoCatalogo>))]
    [JsonSerializable(typeof(ProductoCatalogo))]
    [JsonSerializable(typeof(VentasExportacionJson))]
    [JsonSerializable(typeof(ExportacionMeta))]
    [JsonSerializable(typeof(List<VentaExportacion>))]
    [JsonSerializable(typeof(VentaExportacion))]
    [JsonSerializable(typeof(List<DetalleExportacion>))]
    [JsonSerializable(typeof(DetalleExportacion))]
    [JsonSerializable(typeof(List<PagoExportacion>))]
    [JsonSerializable(typeof(PagoExportacion))]
    [JsonSerializable(typeof(DetalleTransferenciaExportacion))]
    [JsonSerializable(typeof(ConfiguracionApp))]
    [JsonSourceGenerationOptions(
        WriteIndented = true,
        PropertyNamingPolicy = JsonKnownNamingPolicy.Unspecified)]
    internal partial class JsonContexto : JsonSerializerContext { }
}