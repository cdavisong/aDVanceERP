﻿using aDVanceERP.Core.Eventos;
using aDVanceERP.Core.Infraestructura.Globales;
using aDVanceERP.Core.Modelos.Comun;
using aDVanceERP.Core.Modelos.Modulos.Inventario;
using aDVanceERP.Core.Presentadores.Comun;
using aDVanceERP.Core.Repositorios.Modulos.Inventario;
using aDVanceERP.Modulos.Inventario.Interfaces;

namespace aDVanceERP.Modulos.Inventario.Presentadores {
    public class PresentadorRegistroAlmacen : PresentadorVistaRegistro<IVistaRegistroAlmacen, Almacen, RepoAlmacen, FiltroBusquedaAlmacen> {
        public PresentadorRegistroAlmacen(IVistaRegistroAlmacen vista) : base(vista) {
            AgregadorEventos.Suscribir("MostrarVistaRegistroAlmacen", OnMostrarVistaRegistroAlmacen);
            AgregadorEventos.Suscribir("MostrarVistaEdicionAlmacen", OnMostrarVistaEdicionAlmacen);
        }

        private void OnMostrarVistaRegistroAlmacen(string obj) {
            Vista.ModoEdicion = false;
            Vista.Restaurar();
            Vista.Mostrar();
        }

        private void OnMostrarVistaEdicionAlmacen(string obj) {
            Vista.ModoEdicion = true;
            Vista.Restaurar();

            if (string.IsNullOrEmpty(obj))
                return;

            var almacen = AgregadorEventos.DeserializarPayload<Almacen>(obj);

            if (almacen == null)
                return;

            PopularVistaDesdeEntidad(almacen);

            Vista.Mostrar();
        }

        public override void PopularVistaDesdeEntidad(Almacen objeto) {
            base.PopularVistaDesdeEntidad(objeto);

            Vista.NombreAlmacen = objeto.Nombre;
            Vista.Direccion = objeto.Direccion;
            Vista.Descripcion = objeto.Descripcion;
            Vista.Tipo = objeto.Tipo;
        }

        protected override Almacen? ObtenerEntidadDesdeVista() {
            return new Almacen {
                Id = _entidad?.Id ?? 0,
                Nombre = Vista.NombreAlmacen,
                Descripcion = Vista.Descripcion,
                Direccion = Vista.Direccion,
                Tipo = Vista.Tipo,
                Estado = true
            }; 
        }

        protected override async void RegistroEdicionAuxiliar(RepoAlmacen repositorio, long id) {
            if (!Vista.ModoEdicion)
                AgregadorEventos.Publicar("AlmacenRegistrado", AgregadorEventos.SerializarPayload(Entidad));
        }

        protected override bool EntidadCorrecta() {
            var repoAlmacen = RepoAlmacen.Instancia;
            var nombreRepetido = !Vista.ModoEdicion && repoAlmacen.Buscar(FiltroBusquedaAlmacen.Nombre, Vista.NombreAlmacen).cantidad > 0;
            var nombreOk = !string.IsNullOrEmpty(Vista.NombreAlmacen) && !nombreRepetido;
            var almacenPrimarioUnicoOk = repoAlmacen.ExisteAlmacenPrimario()
                ? Vista.Tipo == TipoAlmacenEnum.Primario
                    ? false
                    : true
                : true;

            if (nombreRepetido)
                CentroNotificaciones.MostrarNotificacion("Ye existe un almacén con el mismo nombre registrado en el sistema, los nombres de almacenes deben ser únicos.", TipoNotificacionEnum.Advertencia);
            if (!nombreOk)
                CentroNotificaciones.MostrarNotificacion("El campo de nombre es obligatorio para el almacén, por favor, corrija los datos entrados", TipoNotificacionEnum.Advertencia);
            if (!almacenPrimarioUnicoOk)
                CentroNotificaciones.MostrarNotificacion("Ya existe un almacén primario registrado en el sistema, solo puede haber un almacén primario.", TipoNotificacionEnum.Advertencia);

            return nombreOk && almacenPrimarioUnicoOk;
        }

        public override void Dispose() {
            AgregadorEventos.Desuscribir("MostrarVistaRegistroAlmacen", OnMostrarVistaRegistroAlmacen);
            AgregadorEventos.Desuscribir("MostrarVistaEdicionAlmacen", OnMostrarVistaEdicionAlmacen);

            base.Dispose();
        }
    }
}