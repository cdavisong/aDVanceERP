﻿using aDVanceERP.Core.Vistas.Comun.Interfaces;

namespace aDVanceERP.Modulos.Inventario.Interfaces {
    internal interface IVistaRegistroUnidadMedida : IVistaRegistro {
        string Nombre { get; set; }
        string Abreviatura { get; set; }
        string Descripcion { get; set; }
    }
}