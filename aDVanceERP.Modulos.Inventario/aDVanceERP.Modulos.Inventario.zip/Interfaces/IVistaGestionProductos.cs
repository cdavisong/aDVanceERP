﻿using aDVanceERP.Core.Modelos.Comun.Interfaces;
using aDVanceERP.Core.Modelos.Modulos.Inventario;
using aDVanceERP.Core.Vistas.Comun.Interfaces;

namespace aDVanceERP.Modulos.Inventario.Interfaces {
    public interface IVistaGestionProductos : IVistaContenedor, IGestorEntidades, IBuscadorEntidades<FiltroBusquedaProducto>, INavegadorTuplasEntidades {
        string? NombreAlmacen { get; }
        decimal ValorTotalInventario { get; }

        event EventHandler? GenerarCatalogoProductos;

        void CargarFiltroAlmacenes(object[] nombresAlmacenes);
    }
}